import { Component, signal } from '@angular/core';


import { FormsModule } from '@angular/forms'

@Component({
  selector: 'app-root',
  imports: [FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('calcoloarea');


  AltezzaFigura: number = 0

  BaseFigura: number = 0;

  Divisore: number = 1


  risultato: string = "Valore iniziale"

  calcolo(): void {
    let Area: number = (this.AltezzaFigura * this.BaseFigura) / this.Divisore

    this.risultato = "Il calcolo dell'area è: " + Area

    //this.risultato="La figura di tipo: xxx ha un'area calcolata di:yyy";

  }


}
